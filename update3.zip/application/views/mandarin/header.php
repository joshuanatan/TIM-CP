
<section class="banner-area relative" id="home">	
    <div class="overlay overlay-bg"></div>
    <div class="container">				
        <div class="row d-flex align-items-center justify-content-center">
            <div class="about-content col-lg-12">
                <h1 class="text-white">
                    <?php echo $judul; ?>				
                </h1>	
                <p class="text-white link-nav"><a href="<?php echo base_url();?>zh/index">HOME</a>  <span class="lnr lnr-arrow-right"></span> <?php echo $judul; ?></p>
            </div>	
        </div>
    </div>
</section>