
<section class="home-about-area relative" style = "padding-top:80px;padding-bottom:80px">			
    <div class="container">
        <div class="row align-items-center justify-content-start">
            <div class="col-lg-6 no-padding home-about-right">
                <h1>
                    Pdt. Hasan Sutanto, D.Th
                </h1>
                <p style = "text-align:justify">
                    <span class = "chinnese" style = "font-size:30px">陈南山牧师/博士，祖籍福建南安，印尼华侨。于1987年被按立为牧师。</span>
                </p>
                <br>
            </div>
        </div>
    </div>	
</section>
