
<section class="banner-area" id="home" style = "padding-top:80px;padding-bottom:80px">
    <div class="container">
        <div class="row fullscreen d-flex align-items-center">
            <div class="banner-content col-lg-12 col-md-12 justify-content-center ">
                <h6 class="text-uppercase">
                    <span class = "chinnese" style = "color:white" >文字事工小组</span> TIM IKHLAS MENGABDI
                </h6> 
                <h1 style="font-size: 60px; text-align:justify">
                    简称 TIM
                </h1>
                <p class="text-white chinnese" style = "font-size: 20px; letter-spacing: 2; line-height:1; width: 80%">
                    文字事工小组(简称TIM)是一个由几位基督徒组成的团聚。这个团聚的宗旨是支持陈南山牧师/博士在研究和写作方面的服侍。这个支持包括赞助在印尼受神学教育的神学生订购陈牧师的著作
                </p>
            </div>	
        </div>
    </div>
</section>