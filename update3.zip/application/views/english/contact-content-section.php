<?php foreach($contact as $a ){ ?>
<section class="contact-page-area section-gap" style = "padding-top:120px; padding-bottom:120px">
    <div class="container">
        <div class="row">
            <h3 style = "text-align:center">The easiest way to contact TIM or Rev. Hasan Sutanto, D.Th. is filling out the form below or writing an email to: <br><br>tim.for.book@gmail.com.<br>tim.for.book@yahoo.com.</h3>
        </div>
    </div>	
</section>
 <?php }?>