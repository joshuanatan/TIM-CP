<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'hasansut_wor2');

/** MySQL database username */
define('DB_USER', 'hasansut_wor2');

/** MySQL database password */
define('DB_PASSWORD', 'J36C72ab');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '~N~.9z1HYby;@tEE<dco{d1H:TI#!lWY_;VT8wgV]-N4e]&D~xF[|@p+]W|n}/w8');
define('SECURE_AUTH_KEY',  'jUeHX@RoY85e~]e~7:+:aMw$K4nq.^1uS-rGL#Q-HcB3Jgb|7#32F*3C}5%{vIyd');
define('LOGGED_IN_KEY',    '=OA>!DOX|^e$80seCMe>|]>QL%OzGnA]I(|YoIVK/cA|k#@_4q]}A@R:UWJxwysW');
define('NONCE_KEY',        ',`iUwfTj#p;U7np{P?(vZ8axAynERMoXk:Er6L#JAo}bP|2pV$C@l<FGy-iPi+Th');
define('AUTH_SALT',        ' .QmH(yWU>Ikm9^08z@>ZV22/Kax#!h=[P.SpI=aP|#_3<IPrz z3p2|r`f &`DN');
define('SECURE_AUTH_SALT', '+L9&+0H-~#I&ZDS+j}.+()H1x:+n;IZgl?0*{+rJ[mI7<mvUoe}a$oA;5%=4Tj+r');
define('LOGGED_IN_SALT',   'T4c+D_^B0V=~3;lkJ`b5S[fYAe[z7 R4+:$:0/vNqiFm`;znwm`yu~5M4b]ZeiP)');
define('NONCE_SALT',       ';pG:47KYj+/<Fc:xRF:UzG-xON?S~>-3I5+O+]B0i{ck;uSzDitH&x-iBn-cI97y');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'xfz_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
