<?php defined("BASEPATH") OR exit("No Direct Script"); 
$counter = 0;
$datas = array();
foreach($about as $data){ ?>
<section class="home-about-area relative" style = "padding:100px">			
    <div class="container">
        <div class="row align-items-center justify-content-start">
            <div class="col-lg-6 no-padding home-about-right">
                <h1>
                    <?php echo $data->name; ?>
                </h1>
                <p>
                    <?php echo $data->description; ?>
                </p>
                <br>
            </div>
        </div>
    </div>	
</section>

<?php
}
?>