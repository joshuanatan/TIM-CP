<?php
defined('BASEPATH') OR exit("No Direct Script");
$contents = array();
$counter = 0;
foreach($konten as $a){
    $contents[$counter] = $a->content;
    $counter++;
}
?>

<section class="service-area section-gap" id="service">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 pb-50 header-text text-center">
                
                <h3 class="mb-10" style = "text-align:justify; text-align-last:center">
                    <?php echo $contents[0];?>
                </h3>
                <br>
                <a href = "mailto:<?php echo $contents[1];?>" style = "font-size: 30px">
                    
                    <?php echo $contents[1];?>
                </a>
            </div>
        </div>						
        <div class="row single-service" style = "background-color:none">
            <div class = "col-lg-12 col-md-12 col-sm-12" style = "margin:5%">
                <h4>TERMS AND CONDITION</h4>
                <ul>
                <?php foreach ($ta as $a){ ?> 
                <li style = "list-style:disc"><?php echo $a->terms; ?></li>
                    <br/>
                <?php }?>
                </ul>
            </div>
        </div>
    </div>	
</section>
              