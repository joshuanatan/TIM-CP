
<section class="home-about-area section-gap relative">			
    <div class="container">
        <div class="row align-items-center justify-content-start">
            <div class="col-lg-6 no-padding home-about-right">
                <h1>
                    We can fix all types <br>
                    of computer & mobiles
                </h1>
                <p>
                    inappropriate behavior is often laughed off as “boys will be boys,” women face higher conduct standards especially in the workplace. That’s why it’s crucial that, as women, our behavior on the job is beyond reproach.
                </p>
                <div class="row no-gutters">
                    <div class="single-services col">
                        <span class="lnr lnr-diamond"></span>
                        <a href="#">
                            <h4>Expert Services</h4>
                        </a>
                        <p>
                            Usage of the Internet is becoming more common due to rapid advancement of technology.
                        </p>
                    </div>
                    <div class="single-services col">
                        <span class="lnr lnr-phone"></span>
                        <a href="#">
                            <h4>Great Support</h4>
                        </a>
                        <p>
                            Usage of the Internet is becoming more common due to rapid advancement of technology.
                        </p>
                    </div>								
                </div>
            </div>
        </div>
    </div>	
</section>