<?php
defined("BASEPATH") OR exit("No Direct Script");
?>
<header id="header" id="home">
    <div class="container main-menu">
        <div class="row align-items-center justify-content-between d-flex">
          <div id="logo">
            <a href="<?php echo base_url();?>hs/index"><img src="<?php echo base_url();?>assets/img/logo2.png" alt="" title="" /></a>
          </div>
          <nav id="nav-menu-container">
            <ul class="nav-menu">
                <?php foreach($navigation as $data){ ?> 
                <li><a href="<?php echo base_url();?>hs/<?php echo $data->links;?>"><?php echo $data->nama; ?></a></li>
                <?php }?>
                <li>
                    <form action = "<?php echo base_url();?>hs/getLang" method = "post">
                        <select style = "font-weight: bolder; background:none; border-left:none; border-right:none; border-top:none" onchange = "changeLang()" id = "language" name = "language">
                            <option value = "en" <?php if($this->session->lang == "en") echo "selected" ?>>ENGLISH</option>
                            <option value = "id" <?php if($this->session->lang == "id") echo "selected" ?>>BAHASA INDONESIA</option>
                            <option value = "zh" <?php if($this->session->lang == "zh") echo "selected" ?>>中文</option>
                        </select>
                    </form>
                </li>
            </ul>
          </nav><!-- #nav-menu-container -->		    		
        </div>
    </div>
</header>
<script>
function changeLang(){
    document.getElementById("language").form.submit();
}
</script>