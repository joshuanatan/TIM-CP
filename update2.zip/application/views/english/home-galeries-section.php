
<section class="testomial-area section-gap" id="testimonail">
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="menu-content pb-60 col-lg-7">
                <div class="title text-center">
                    <h1 class="mb-10 text-white">Feedback from our real clients</h1>
                    <p class="text-white">It won’t be a bigger problem to find one video game lover in your neighbor. Since the introduction of Virtual Game.</p>
                </div>
            </div>
        </div>						
        <div class="row">
            <div class="active-testimonial-carusel">
                <div class="single-testimonial item">
                    <img class="mx-auto" src="img/t1.png" alt="">
                    <p class="desc">
                        Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker, projector, hardware and more. laptop accessory
                    </p>
                    <h5>Mark Alviro Wiens</h5>
                    <p>
                        CEO at Google
                    </p>
                </div>
                <div class="single-testimonial item">
                    <img class="mx-auto" src="img/t2.png" alt="">
                    <p class="desc">
                        Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker, projector, hardware and more. laptop accessory
                    </p>
                    <h5>Mark Alviro Wiens</h5>
                    <p>
                        CEO at Google
                    </p>
                </div>
                <div class="single-testimonial item">
                    <img class="mx-auto" src="img/t3.png" alt="">
                    <p class="desc">
                        Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker, projector, hardware and more. laptop accessory
                    </p>
                    <h5>Mark Alviro Wiens</h5>
                    <p>
                        CEO at Google
                    </p>
                </div>	
                <div class="single-testimonial item">
                    <img class="mx-auto" src="img/t1.png" alt="">
                    <p class="desc">
                        Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker, projector, hardware and more. laptop accessoryawefawfewafawefawefawefaefawefawefawefawefawef 
                    </p>
                    <h5>Mark Alviro Wiens</h5>
                    <p>
                        CEO at Google
                    </p>
                </div>
                <div class="single-testimonial item">
                    <img class="mx-auto" src="img/t2.png" alt="">
                    <p class="desc">
                        Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker, projector, hardware and more. laptop accessory
                    </p>
                    <h5>Mark Alviro Wiens</h5>
                    <p>
                        CEO at Google
                    </p>
                </div>
                <div class="single-testimonial item">
                    <img class="mx-auto" src="img/t3.png" alt="">
                    <p class="desc">
                        Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker, projector, hardware and more. laptop accessory
                    </p>
                    <h5>Mark Alviro Wiens</h5>
                    <p>
                        CEO at Google
                    </p>
                </div>															
                <div class="single-testimonial item">
                    <img class="mx-auto" src="img/t1.png" alt="">
                    <p class="desc">
                        Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker, projector, hardware and more. laptop accessory
                    </p>
                    <h5>Mark Alviro Wiens</h5>
                    <p>
                        CEO at Google
                    </p>
                </div>
                <div class="single-testimonial item">
                    <img class="mx-auto" src="img/t2.png" alt="">
                    <p class="desc">
                        Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker, projector, hardware and more. laptop accessory
                    </p>
                    <h5>Mark Alviro Wiens</h5>
                    <p>
                        CEO at Google
                    </p>
                </div>
                <div class="single-testimonial item">
                    <img class="mx-auto" src="img/t3.png" alt="">
                    <p class="desc">
                        Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker, projector, hardware and more. laptop accessory
                    </p>
                    <h5>Mark Alviro Wiens</h5>
                    <p>
                        CEO at Google
                    </p>
                </div>														
            </div>
        </div>
    </div>	
</section>