<?php defined("BASEPATH") OR exit("No Direct Script"); ?>
<section class="home-about-area relative" style = "padding:100px">			
    <div class="container">
        <div class="row align-items-center justify-content-start">
            <div class="col-lg-6 no-padding home-about-right">
                <h1>
                    Pdt. Hasan Sutanto, D.Th
                </h1>
                <p style = "font-size: 32px; line-height: 1.5">
                    陈南山牧师/博士，祖籍福建南安，印尼华侨。于1987年被按立为牧师。
                </p>
                <br>
            </div>
        </div>
    </div>	
</section>
