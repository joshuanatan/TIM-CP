<?php
defined("BASEPATH") OR exit("No Direct Script");
?>
<header id="header" id="home">
    <div class="container main-menu">
        <div class="row align-items-center justify-content-between d-flex">
          <div id="logo">
            <a href="<?php echo base_url();?>zh/index"><img src="<?php echo base_url();?>assets/img/logo2.png" alt="" title="" /></a>
          </div>
          <nav id="nav-menu-container">
            <ul class="nav-menu">
                <li><a href="<?php echo base_url();?>zh/index">文字事工小组</a></li>
                <li><a href="<?php echo base_url();?>zh/aboutus">学历</a></li>
                <li><a href="<?php echo base_url();?>zh/projects">著作</a></li>
                <li><a href="<?php echo base_url();?>zh/distribution">distribusi</a></li>
                <li><a href="<?php echo base_url();?>zh/sermons">khotbah</a></li>
                <li><a href="<?php echo base_url();?>zh/contact">hubungi kami</a></li>
                <li>
                    <form action = "<?php echo base_url();?>zh/getLang" method = "post">
                        <select style = "font-weight: bolder; background:none; border-left:none; border-right:none; border-top:none" onchange = "changeLang()" id = "language" name = "language">
                            <option value = "en" <?php if($this->session->lang == "en") echo "selected" ?>>ENGLISH</option>
                            <option value = "id" <?php if($this->session->lang == "id") echo "selected" ?>>BAHASA INDONESIA</option>
                            <option value = "zh" <?php if($this->session->lang == "zh") echo "selected" ?>>中文</option>
                        </select>
                    </form>
                </li>
            </ul>
          </nav><!-- #nav-menu-container -->		    		
        </div>
    </div>
</header>
<script>
function changeLang(){
    document.getElementById("language").form.submit();
}
</script>